
package lacf66moneymanager;

import javafx.event.ActionEvent;

public interface MoneyManagerFunctionality {
    void handleClear(ActionEvent event);
    void handleSave(ActionEvent event);
    void handleOpen(ActionEvent event);
    
}
